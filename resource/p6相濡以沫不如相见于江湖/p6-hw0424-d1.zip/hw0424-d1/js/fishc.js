$(function(){


    $("#timeline").timelinr({
        autoPlay: 'true',
        autoPlayDirection: 'forward',
        startAt: 1  /*  默认显示第几个 */
    })
});
